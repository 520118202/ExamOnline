<template>
	<div id="error">
		<h1>404错误界面</h1>
		<p>访问的路径不存在</p>
	</div>
</template>

<script>
</script>

<style>
</style>
